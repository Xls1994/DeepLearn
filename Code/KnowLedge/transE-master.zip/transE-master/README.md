transE by Python
======
Train transE.py and test test.py.  
  
If shut down during training, also can run reTrans.py to continue.   
  
Finally, also can use pca.py to dimensionality reduction, and plot in .png  


THANKS
======
* [Paper](https://www.utc.fr/~bordesan/dokuwiki/_media/en/transe_nips13.pdf) (Bordes et al. 2013)
* [Relation_Extraction](https://github.com/mrlyk423/relation_extraction) by Mrlyk423
